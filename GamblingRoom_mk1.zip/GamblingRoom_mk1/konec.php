<?php
session_start();

?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <link rel="stylesheet"  href="styles/styles.css" />
        <title>Gambling</title>
    </head>
    <body>
        <div id="naslov">
            <h1>REZULTATI</h1>
        </div>
        <div id="igrac">
		<?php
       
		
		if($_SESSION["vsota3"]<=$_SESSION["vsota1"] && $_SESSION["vsota1"]>=$_SESSION["vsota2"]){
			if($_SESSION["vsota1"]==$_SESSION["vsota2"] && $_SESSION["vsota1"]==$_SESSION["vsota3"]){
				echo "<div id=\"glavni\" >Zmagovalca sta:</div>",$_SESSION["i1"]," ,",$_SESSION["i2"]," ",$_SESSION["i3"];
			}
			elseif($_SESSION["vsota1"]==$_SESSION["vsota2"]){
				echo "<div id=\"glavni\">Zmagovalca sta: " . $_SESSION["i1"] . ", " . $_SESSION["i2"] . "</div>";
			}
			elseif($_SESSION["vsota1"]==$_SESSION["vsota3"]){
				echo "<div id=\"glavni\">Zmagovalca sta: " . $_SESSION["i1"] . " ," . $_SESSION["i3"] . "</div>";
			}
			else{
				echo "<div id=\"glavni\" >Zmagovalec je: " .$_SESSION["i1"]."</div>";	
			}
		}
	
		elseif($_SESSION["vsota2"]>=$_SESSION["vsota3"]){
			if($_SESSION["vsota2"]>$_SESSION["vsota1"]){
				echo "<div id=\"glavni\" >Zmagovalec je: " .$_SESSION["i2"]."</div>";	
			}
			else{
				echo "<div id=\"glavni\" >Zmagovaleca sta: " . $_SESSION["i2"] . " ," . $_SESSION["i3"] ."</div>";	
			}
		}
		
		else{
			echo "<div id=\"glavni\" >Zmagovalec je: " .$_SESSION["i3"]."</div>";	
		}
		
        //echo $_SESSION["vsota1"]," ",$_SESSION["vsota2"]," ",$_SESSION["vsota3"];
        ?>
		</div>
        
        
    </body>
        <!--skripta za redirect čez 15 sek-->
        <script>
        function redirTimer() {self.setTimeout ("self.location.href='index.php';",10000);} 
        redirTimer();

        var seconds_left = 10;
        setInterval(function() {
            document.getElementById('cas').innerHTML = --seconds_left;}, 1000);
        </script>

</html> 